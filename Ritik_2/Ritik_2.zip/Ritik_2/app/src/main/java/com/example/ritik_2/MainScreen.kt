package com.example.ritik_2

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.ritik_2.ui.theme.Ritik_2Theme

@Composable
fun MainScreen(
    modifier: Modifier = Modifier,
    onCardClick: (Int) -> Unit = {}
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // 🔹 Profile Section
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Welcome, Ritik Saini",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )

            // 🔹 Profile Image with Background Fix
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .background(Color.Gray, shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_baseline_account_circle_24),
                    contentDescription = "Profile Picture",
                    modifier = Modifier.size(50.dp) // Smaller image inside the background
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 🔹 Customizable Grid Layout
        val cardItems = listOf(
            Pair(1, "Register a Complaint"),
            Pair(2, "View Complaints"),
            Pair(3, "Settings"),
            Pair(4, "Help & Support")
        )
        GridLayout(items = cardItems, onCardClick = onCardClick)
    }

}
